# Methods

## Checkpoints
* **OLMo-2-0425-1B**: base, SFT, DPO, final (Instruct, adds a verifiable-rewards RL stage). Stage-separable ladder. Its preference stage is DPO, not PPO-style RLHF, so we say *preference-based alignment*. English-centric pre-training: Arabic and French are a stress test.
* **Qwen2.5-1.5B**: base and Instruct. More multilingual; stages are not separable.
All checkpoints are public and used as released.

## Lexicon (220 items, `pipeline/lexicon.csv`)
80 culture-specific terms (40 Arabic, 40 French), 20 English dominant-culture reference terms, and 40 neutral concepts in each of Arabic, French and English (120 controls). Each culture term has two English anchors embedded in the same model: a **literal gloss** and a **dominant analogue** (e.g. *zakat*: almsgiving / charity). Each control has its translation as gloss and a **related non-translation anchor** (e.g. water: rain) so the culture-vs-control contrast is symmetric.

## Representation
Six carrier sentences per language (two disjoint halves of three, to estimate reliability). Hidden states are mean-pooled over the term's tokens (character-offset alignment, unit-tested on 924 term-template cases) at every layer. For every model and layer all vectors are mean-centred. Analysed layers: upper half excluding the last (OLMo 8-15; Qwen 14-27) because the last layer is dominated by one dimension (top-1 variance 0.46 OLMo, 0.67 Qwen).

## Metrics
With $\tilde e$ the centred embedding:

* **Profile drift** (basis-free): $\mathrm{PD}(w)=1-\mathrm{corr}_{j\neq w}\big(\cos(\tilde e^{pre}_w,\tilde e^{pre}_j),\ \cos(\tilde e^{post}_w,\tilde e^{post}_j)\big)$
* **Anchor shift**: $\Delta_a(w)=\cos(\tilde e^{post}_w,\tilde a^{post})-\cos(\tilde e^{pre}_w,\tilde a^{pre})$, with $a\in\{\text{analogue},\text{gloss}\}$ (within-model cosines, so no cross-checkpoint comparison)
* **Paired index**: $C(w)=\Delta_{\text{analogue}}(w)-\Delta_{\text{gloss}}(w)$ (cancels general convergence toward English)
* **Cosine drift** $1-\cos(\tilde e^{pre}_w,\tilde e^{post}_w)$ is reported *only* where checkpoints share a coordinate basis (median centred cosine > 0.5).
* kNN turnover (1 - Jaccard of the 5 nearest same-language neighbours) as a robustness metric.

## Inference
Culture vs control, per language: $y_w=\beta_0+\beta_1\,\mathrm{culture}_w+\gamma_1 b_w+\gamma_2 n_w+\varepsilon_w$ where $b$ is baseline similarity to the relevant anchor and $n$ the token count. Freedman-Lane permutation test (10,000), stratified bootstrap 95% CI (5,000), Hedges' g, Holm correction. Primary family = {profile drift, shift toward analogue} x {Arabic, French} on the primary contrast; everything else is exploratory and corrected within its own family.

## Validation (synthetic, `validation/`)
* Naive culture-vs-control comparison of change scores: 28-85% false positives at zero true effect; baseline-adjusted test: 5-7%.
* Basis-free metrics are invariant to rotating a checkpoint's basis (max difference ~3e-7); cosine drift is not (1.36).
* Positive control: an effect planted at one stage and one language pair, with the base checkpoint in a randomly rotated basis, is recovered at the right stage and languages and nowhere else.
