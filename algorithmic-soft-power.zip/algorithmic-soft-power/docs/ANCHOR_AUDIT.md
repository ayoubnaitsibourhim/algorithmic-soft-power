# Anchor audit

All 80 culture-specific term-anchor pairs were audited on **gloss accuracy** (A accurate / B approximate), **analogue strength** (S strong: a documented or common dominant-culture reframing / P plausible / W weak: near-synonym or too generic) and confound flags (POLY polysemy or unvocalised homograph, COG orthographic cognate with the gloss, LOAN English loanword, DISC analogue is a near-synonym or standard translation, DUP analogue reused within the language, REG region-specific, PN proper noun or given name). Per-item results: `pipeline/anchor_audit.csv`.

| | Arabic (40) | French (40) |
|---|---|---|
| Gloss accurate / approximate | 34 / 6 | 33 / 7 |
| Analogue strong / plausible / weak | 13 / 15 / 12 | 13 / 19 / 8 |
| POLY / COG / DISC | 8 / 0 / 8 | 2 / 13 / 4 |

**Limitation:** this audit was done by **a single annotator (an AI assistant)** and is *not* independent validation. Two independent bilingual annotators should rate every pair (`pipeline/annotation_template.csv`; agreement via `pipeline/kappa.py`). Sensitivity sets: `exclude_ambiguous.csv`, `exclude_weak.csv`, `exclude_all_flagged.csv`, `keep_strong_only.csv`, used with `run_analysis.py --exclude_file / --keep_file` (no re-extraction needed).
