# Analysis plan and amendments

**Not externally pre-registered.** The original plan (v1) was written into the header of `run_analysis.py` before the first run.

| | v1 (original) | v2 (amended) |
|---|---|---|
| Primary contrast | base -> final | **SFT -> final** (preference stages, shared basis) |
| Primary metrics | cosine drift, shift toward analogue | **profile drift**, shift toward analogue |
| Layers | upper half incl. last | upper half **excluding last** |
| Lexicon | 25 items per group; controls anchored to literal translations | 40 per group; controls anchored to related non-translation words |

**Why:** diagnostics on run 1 showed (i) no shared coordinate basis between the OLMo base checkpoint and every post-trained checkpoint (centred cosine ~0 even at the embedding layer, while RSA 0.88-0.97), so cosine drift across that boundary is meaningless; (ii) a last layer dominated by one dimension; (iii) an anchor asymmetry that made the culture-vs-control contrast measure anchor type (run 1 produced a significant effect of the *opposite* sign).

**Disclosure:** these are measurement-validity changes, but they were made after the authors had seen run-1 summary statistics. Run 1 results are kept in `results/raw/run1_original_*`.
