# Algorithmic Soft Power? Measuring Semantic Contamination of Culturally Situated Concepts Under Preference Alignment in Multilingual Latent Spaces

**Ayoub Nait Si Bourhim** (ENCG Fès, Sidi Mohammed Ben Abdellah University; Laremef Lab) and **Mohammed Ali Boulaich**
Presented at the 11th UNICART International Conference, University of Palermo, 12 November 2026 (online).

> **Status: research in progress.** Small open models (1-1.5B parameters), 40 terms per group, anchors audited by a single AI-assisted annotator. Read the [limitations](#limitations) before citing any number.

## Question
Do the post-training stages in which language models are tuned to follow human preferences pull culturally specific Arabic and French terms (*zakat*, *shura*, *laïcité*, *banlieue*) toward the English concepts that tend to stand in for them in international discourse (*charity*, *democracy*, *religious freedom*, *ghetto*)? We call movement of this kind **semantic contamination**, test it on public checkpoints, and report what the data do and do not support.

## Headline findings (OLMo-2 1B and Qwen2.5 1.5B)
1. **Preference stages barely change term geometry.** Similarity-profile drift is 0.2-0.5% from SFT to DPO and about 0.01% from DPO to the final stage, and cultural terms do not differ from neutral controls.
2. **One small Arabic effect.** Arabic culture terms gain slightly more similarity to their dominant analogue than controls do (OLMo +0.0037, 95% CI +0.0017 to +0.0058, Holm p = 0.0008; Qwen +0.0030, CI -0.0007 to +0.0066, not reliable). About 78% of it arises at the DPO stage.
3. **It is not analogue-specific.** The shift toward the *literal translation* is almost identical (+0.0035), and the within-term paired index is -0.0013 (CI -0.0033 to +0.0008). Arabic terms move toward English in general, not toward the analogue in particular.
4. **No consistent French pattern.** French culture terms are, if anything, slightly *more* stable than controls (Qwen, Holm p = 0.038).
5. **Two measurement traps** nearly produced wrong answers: raw cosine drift is invalid across checkpoints that do not share a coordinate basis (OLMo base vs every post-trained checkpoint: centred cosine ~0, RSA 0.88-0.97), and naive culture-vs-control comparisons of change scores gave 28-85% false positives in simulation (5-7% after baseline adjustment).

Evidence for systematic cultural assimilation is therefore **weak at this scale**; that does not establish behavioural neutrality.

## Key results
Adjusted culture-minus-control differences (cosine units), primary family, Holm-corrected. Full tables: [`results/`](results/).

| Run | Test | Estimate [95% CI] | Holm p |
|---|---|---|---|
| OLMo-2 1B, SFT→Instruct | Profile drift, Arabic | +0.0003 [-0.0004, +0.0011] | .747 |
| | Profile drift, French | -0.0004 [-0.0010, +0.0000] | .230 |
| | Shift toward analogue, Arabic | **+0.0037 [+0.0017, +0.0058]** | **.0008** |
| | Shift toward analogue, French | +0.0013 [-0.0011, +0.0036] | .747 |
| OLMo-2 1B, dim-standardised | Shift toward analogue, Arabic | +0.0026 [+0.0009, +0.0045] | .019 |
| Qwen2.5 1.5B, base→Instruct | Profile drift, French | -0.0005 [-0.0010, -0.0001] | .038 |
| | Shift toward analogue, Arabic | +0.0030 [-0.0007, +0.0066] | .389 |
| | Shift toward analogue, French | +0.0027 [-0.0007, +0.0062] | .389 |

**Stage attribution (OLMo, Arabic culture − control, exploratory):** SFT→DPO +0.0029 [+0.0009, +0.0050]; DPO→Instruct +0.0008 [+0.0003, +0.0013]; total +0.0037. Literal-translation shift: +0.0027, +0.0008, +0.0035.

**Where geometry changes (profile drift, Arabic culture terms):** base→SFT 17.6%* · SFT→DPO 0.53% · DPO→final 0.012%. *crosses an unexplained coordinate break; read as an upper bound.

![basis continuity](figures/fig1_basis_continuity.png)
![primary effects](figures/fig2_primary_effects.png)
![stage attribution](figures/fig3_stage_attribution.png)
![simulation](figures/fig4_simulation.png)

## Repository layout
```
pipeline/     code, lexicon (220 items), anchor audit, exclusion sets, annotation tools
results/      key_results*.csv (headline tables), MANIFEST.md, raw/ (original run outputs)
validation/   synthetic validation (simulation, planted-effect positive control)
figures/      figures above
docs/         METHODS.md, AMENDMENTS.md, ANCHOR_AUDIT.md
```

## Reproduce
```bash
pip install -r requirements.txt            # extraction needs a GPU (a free Colab/Kaggle T4 is enough)
cd pipeline && bash run_all.sh             # ~30 min: extracts embeddings for 6 checkpoints, runs diagnostics and analysis
python make_key_results.py                 # (from repo root) rebuild the headline table from raw outputs and compare
```
Checkpoints: `allenai/OLMo-2-0425-1B` (+`-SFT`, `-DPO`, `-Instruct`) and `Qwen/Qwen2.5-1.5B` (+`-Instruct`). Embeddings are rejected if they were extracted with a different lexicon version (signature check). Anchor-quality sensitivity runs and the human-agreement tool are described in [`docs/ANCHOR_AUDIT.md`](docs/ANCHOR_AUDIT.md).

## Analysis plan and amendments
Not externally pre-registered. The plan changed after run-1 diagnostics (coordinate-basis discontinuity, one-dimension-dominated final layer, asymmetric anchors). Both analyses are reported; see [`docs/AMENDMENTS.md`](docs/AMENDMENTS.md).

## Limitations
* Two 1-1.5B-parameter model families; OLMo is English-centric, Qwen cannot separate SFT from preference stages; OLMo's preference stage is DPO, not PPO-style RLHF.
* Anchors (especially the dominant analogues) are researcher-defined. The audit is **single-annotator and AI-assisted**; independent human validation is pending. French cognates (13/40) and Arabic polysemy (8/40) are flagged confounds.
* 40 terms per group, Modern Standard Arabic only, not frequency-matched. No equivalence test against a pre-specified margin yet. No behavioural (generation-based) validation.
* Stage contrasts other than SFT→final are exploratory. The base-checkpoint coordinate break is documented but unexplained.
* Embedding proximity in carrier sentences is a coarse proxy for meaning. Absence of geometric drift does not show that model outputs are culturally neutral.

## AI-assistance disclosure
The analysis code, anchor audit, figures and first drafts of the text were produced with substantial assistance from an AI system (Claude, Anthropic). The authors ran the experiments, reviewed the results and are responsible for the content.

## Citation and license
See [`CITATION.cff`](CITATION.cff). Code and data: MIT ([`LICENSE`](LICENSE)). Contact: [add e-mail].
