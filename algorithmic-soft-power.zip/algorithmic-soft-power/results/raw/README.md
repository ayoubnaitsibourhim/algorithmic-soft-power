# Raw run outputs

Put your original result files here, renamed as listed in ../MANIFEST.md.
Then run `python pipeline/make_key_results.py` from the repository root to verify results/key_results.csv.
