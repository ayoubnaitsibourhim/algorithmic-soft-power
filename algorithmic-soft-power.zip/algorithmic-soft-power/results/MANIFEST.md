# Results manifest

`key_results*.csv` (in this folder) are compact tables transcribed from the run summaries so the headline numbers are
visible without opening anything else. The **raw outputs of the actual runs** go in `results/raw/` under the names below
(copy your original files from Colab and rename them as shown; nothing else needs to change).

| Original file (as downloaded) | Save as in `results/raw/` | What it is |
|---|---|---|
| `results (1).csv` (90 rows; contrasts base->sft ... dpo->instruct) | `olmo_v2_results.csv` | OLMo-2 1B, all stage contrasts, v2 analysis |
| `summary (3).md` | `olmo_v2_summary.md` | OLMo-2 1B primary summary (SFT->Instruct) |
| `summary (4).md` | `olmo_v2_standardised_summary.md` | same, per-dimension standardised |
| `paired.csv` | `olmo_v2_paired.csv` | paired index by group and contrast |
| `basis_continuity.csv` | `olmo_v2_basis_continuity.csv` | basis-continuity diagnostic |
| `diagnostics_olmo.txt` | `diagnostics_olmo.txt` | per-layer cosine / RSA / CKA / reliability |
| `results (2).csv` or `results (3).csv` (identical, 15 rows) | `qwen_results.csv` | Qwen2.5 1.5B, base->instruct |
| `summary (5).md` | `qwen_summary.md` | Qwen primary summary |
| `basis_continuity (1).csv` | `qwen_basis_continuity.csv` | Qwen basis continuity |
| `diagnostics_qwen.txt` | `diagnostics_qwen.txt` | Qwen diagnostics |
| `results.csv` (48 rows; no `valid` column) | `run1_original_results.csv` | Run 1 under the ORIGINAL plan (superseded; kept for transparency) |
| `summary.md` / `summary (1).md` / `summary (2).md` (identical) | `run1_original_summary.md` | Run 1 summary |

`pipeline/make_key_results.py` rebuilds `key_results.csv` from the raw files so any reader can verify the transcription.
Embeddings (`*.npz`) are not committed; regenerate them with `pipeline/run_all.sh`.
