# Summary (SYNTH-base) | primary contrast sft->instruct | analysed layers 8-15 of 16

## Basis continuity (cosine drift valid only if > 0.5)
- base->sft: median centred cos = -0.071 (layer 0: -0.049) -> cosine drift INVALID
- base->dpo: median centred cos = -0.070 (layer 0: -0.045) -> cosine drift INVALID
- base->instruct: median centred cos = -0.068 (layer 0: -0.044) -> cosine drift INVALID
- sft->dpo: median centred cos = 0.967 (layer 0: 0.948) -> cosine drift valid
- sft->instruct: median centred cos = 0.946 (layer 0: 0.914) -> cosine drift valid
- dpo->instruct: median centred cos = 0.969 (layer 0: 0.951) -> cosine drift valid

## Primary family (Holm)
- profile_drift [ar]: adj. culture-control diff = +0.0087 (95% CI +0.0028, +0.0147); p = 0.0055, Holm p = 0.0110; raw means 0.1118 vs 0.1050, g = 0.66
- profile_drift [fr]: adj. culture-control diff = +0.0095 (95% CI +0.0045, +0.0149); p = 0.0005, Holm p = 0.0020; raw means 0.1127 vs 0.1038, g = 0.98
- shift_analog [ar]: adj. culture-control diff = +0.0472 (95% CI +0.0155, +0.0825); p = 0.0055, Holm p = 0.0110; raw means 0.0378 vs -0.0300, g = 5.69
- shift_analog [fr]: adj. culture-control diff = +0.0566 (95% CI +0.0321, +0.0806); p = 0.0005, Holm p = 0.0020; raw means 0.0385 vs -0.0282, g = 6.12

## Paired within-term test: shift toward analogue minus shift toward literal gloss (>0 = contamination direction)
- culture_ar: +0.0528 (95% CI +0.0481, +0.0574), Holm p = 0.0030, n = 40
- culture_fr: +0.0540 (95% CI +0.0504, +0.0575), Holm p = 0.0030, n = 40
- control_ar: +0.0004 (95% CI -0.0005, +0.0013), Holm p = 1.0000, n = 40
- control_fr: +0.0005 (95% CI -0.0003, +0.0013), Holm p = 1.0000, n = 40
- dominant_en: +0.0002 (95% CI -0.0010, +0.0015), Holm p = 1.0000, n = 20

## Exploratory results with Holm p < .05
- base->dpo shift_analog [fr]: adj diff +0.0470 CI (+0.0211, +0.0711), Holm p = 0.0385
- base->dpo shift_gloss [ar]: adj diff +0.0198 CI (+0.0156, +0.0240), Holm p = 0.0385
- base->dpo shift_gloss [fr]: adj diff +0.0143 CI (+0.0078, +0.0202), Holm p = 0.0385
- base->instruct shift_analog [fr]: adj diff +0.0604 CI (+0.0295, +0.0905), Holm p = 0.0385
- base->instruct shift_gloss [ar]: adj diff +0.0158 CI (+0.0099, +0.0218), Holm p = 0.0385
- sft->dpo profile_drift [fr]: adj diff +0.0066 CI (+0.0036, +0.0098), Holm p = 0.0385
- sft->dpo drift [ar]: adj diff +0.0038 CI (+0.0022, +0.0053), Holm p = 0.0385
- sft->dpo drift [fr]: adj diff +0.0049 CI (+0.0034, +0.0061), Holm p = 0.0385
- sft->dpo shift_analog [fr]: adj diff +0.0431 CI (+0.0261, +0.0587), Holm p = 0.0385
- sft->dpo shift_gloss [ar]: adj diff +0.0184 CI (+0.0147, +0.0221), Holm p = 0.0385
- sft->dpo shift_gloss [fr]: adj diff +0.0160 CI (+0.0113, +0.0206), Holm p = 0.0385
- sft->instruct drift [fr]: adj diff +0.0061 CI (+0.0040, +0.0080), Holm p = 0.0385
- sft->instruct shift_gloss [ar]: adj diff +0.0144 CI (+0.0085, +0.0199), Holm p = 0.0385
- sft->instruct shift_gloss [fr]: adj diff +0.0151 CI (+0.0098, +0.0202), Holm p = 0.0385
- dpo->instruct drift [ar]: adj diff +0.0032 CI (+0.0018, +0.0046), Holm p = 0.0385