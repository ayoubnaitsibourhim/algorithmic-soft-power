"""Regenerates figures/fig1-3 from the numbers reported in results/key_results.csv and the run diagnostics."""
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False})
ob=([.007,.001,.003,.004,.005,0,-.001,.002,.002,.001,.004,.003,.006,.005,.006,.001,-.001],[.938,.916,.908,.913,.931,.940,.951,.955,.958,.961,.966,.957,.923,.882,.923,.956,.955])
sd=([1,1,1,1,1,.999,.999,.999,.998,.998,.997,.997,.996,.995,.993,.987,.982],[1,1,1,1,1,1,1,1,1,1,1,.999,.999,.998,.994,.996,.992])
qw=([1,.999,.999,.998,.998,.997,.997,.997,.997,.997,.996,.997,.996,.996,.996,.996,.996,.996,.996,.996,.996,.996,.997,.997,.997,.997,.996,.996,.997],[1,1,1]+[.999]*26)
f,ax=plt.subplots(1,3,figsize=(9.5,3),sharey=True)
for a,(c,r),t in zip(ax,(ob,sd,qw),("OLMo-2 1B: base → Instruct","OLMo-2 1B: SFT → DPO","Qwen2.5 1.5B: base → Instruct")):
    a.plot(c,"o-",ms=3,color="#b2182b",label="centred cosine (same word)"); a.plot(r,"s-",ms=3,color="#2166ac",label="RSA (similarity structure)"); a.set_title(t,fontsize=9); a.set_xlabel("layer")
ax[0].set_ylabel("agreement between checkpoints"); ax[0].legend(frameon=False,fontsize=7); f.tight_layout(); f.savefig("figures/fig1_basis_continuity.png",dpi=200)
D=[("PD","Arabic","OLMo",.00035,-.00043,.00113),("PD","French","OLMo",-.00045,-.00095,.00002),("PD","Arabic","OLMo std",.0007,-.0002,.0017),("PD","French","OLMo std",-.0005,-.001,-.0001),("PD","Arabic","Qwen",-.00039,-.0011,.00035),("PD","French","Qwen",-.00053,-.00098,-.00012),
("SA","Arabic","OLMo",.00366,.00172,.00578),("SA","French","OLMo",.00125,-.00114,.0036),("SA","Arabic","OLMo std",.0026,.0009,.0045),("SA","French","OLMo std",.0017,-.0008,.004),("SA","Arabic","Qwen",.00297,-.00068,.00664),("SA","French","Qwen",.0027,-.00067,.00621)]
f,ax=plt.subplots(1,2,figsize=(9.5,3.3)); runs=["OLMo","OLMo std","Qwen"]; col={"Arabic":"#1b7837","French":"#762a83"}
for a,m,t in zip(ax,("PD","SA"),("Profile drift: culture − control","Shift toward analogue: culture − control")):
    for j,r in enumerate(runs):
        for k,l in enumerate(("Arabic","French")):
            x=[d for d in D if d[0]==m and d[1]==l and d[2]==r][0]; y=j+(k-.5)*.3
            a.errorbar(x[3],y,xerr=[[x[3]-x[4]],[x[5]-x[3]]],fmt="o",color=col[l],capsize=2.5,label=l if j==0 else None)
    a.axvline(0,color="grey",ls="--",lw=.8); a.set_yticks(range(3)); a.set_yticklabels(runs); a.invert_yaxis(); a.set_title(t,fontsize=9); a.set_xlabel("adjusted difference, 95% CI (cosine units)")
ax[0].legend(frameon=False); f.tight_layout(); f.savefig("figures/fig2_primary_effects.png",dpi=200)
S=[("SFT→DPO",(.00287,.00091,.00502),(.00272,.00031,.00502)),("DPO→Instruct",(.00078,.00029,.00126),(.00076,.00027,.00126)),("SFT→Instruct",(.00366,.00172,.00578),(.00349,.00108,.00575))]
f,a=plt.subplots(figsize=(6.5,3.4))
for i,(n,an,gl) in enumerate(S):
    for j,(v,c) in enumerate(((an,"#d98c00"),(gl,"#1b7f79"))):
        a.bar(i+(j-.5)*.38,v[0],.34,color=c,label=("toward dominant analogue","toward literal translation")[j] if i==0 else None); a.errorbar(i+(j-.5)*.38,v[0],yerr=[[v[0]-v[1]],[v[2]-v[0]]],color="k",capsize=3)
a.set_xticks(range(3)); a.set_xticklabels([s[0] for s in S]); a.set_ylabel("Arabic culture − control (cosine)"); a.legend(frameon=False); a.set_title("Arabic shift by stage: analogue vs translation (OLMo-2 1B)",fontsize=9); f.tight_layout(); f.savefig("figures/fig3_stage_attribution.png",dpi=200)
