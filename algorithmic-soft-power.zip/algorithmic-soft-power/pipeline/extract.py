"""Extract layer-wise term embeddings from one HF checkpoint.  RUN ON A GPU (Colab / Kaggle).

Usage:
  python extract.py --model allenai/OLMo-2-0425-1B --out emb/olmo_base.npz
  python extract.py --model allenai/OLMo-2-0425-1B-SFT --out emb/olmo_sft.npz
  ...
Representation of a term w: mean over the token positions of w (hidden state at every layer, incl. embedding layer 0)
inside each carrier template, averaged over templates. Two disjoint template halves (A/B) are kept to estimate a
measurement-noise floor. Anchors (English gloss / analogue) are embedded with the English templates in the SAME model.
"""
import argparse, hashlib, numpy as np, pandas as pd

TEMPLATES = {
    "en": ['In this context, the concept of "{t}" refers to',
           "Scholars often debate the meaning of {t}.",
           "The word {t} appears frequently in discussions of society.",
           "People in different regions understand {t} in different ways.",
           "A short definition of {t}:",
           "He explained what {t} means to his students."],
    "fr": ["Dans ce contexte, la notion de « {t} » désigne",
           "Les chercheurs débattent souvent du sens de {t}.",
           "Le mot {t} revient fréquemment dans les discussions sur la société.",
           "Selon les régions, les gens comprennent {t} de manières différentes.",
           "Une brève définition de {t} :",
           "Il a expliqué à ses élèves ce que signifie {t}."],
    "ar": ["في هذا السياق، يشير مفهوم «{t}» إلى",
           "يناقش الباحثون كثيرا معنى {t}.",
           "تتكرر كلمة {t} كثيرا في النقاشات حول المجتمع.",
           "يفهم الناس في مناطق مختلفة {t} بطرق مختلفة.",
           "تعريف موجز لـ {t}:",
           "شرح لطلابه ما يعنيه {t}."],
}


def build_text(template, term):
    pre, post = template.split("{t}")
    return pre + term + post, len(pre), len(pre) + len(term)


def span_token_idx(offsets, s, e):
    """Indices of tokens whose character offsets overlap [s, e). Special tokens (empty offsets) are ignored."""
    idx = [i for i, (a, b) in enumerate(offsets) if b > a and a < e and b > s]
    if not idx:  # defensive fallback: last non-special token before the span end
        idx = [max(i for i, (a, b) in enumerate(offsets) if b > a and a < e)]
    return idx


def main():
    import torch
    from transformers import AutoTokenizer, AutoModel
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--lexicon", default="lexicon.csv")
    ap.add_argument("--revision", default=None)
    ap.add_argument("--dtype", default="float16", choices=["float16", "bfloat16", "float32"])
    ap.add_argument("--load_in_4bit", action="store_true", help="for 7-8B models on a 16GB GPU")
    a = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    dt = dict(float16=torch.float16, bfloat16=torch.bfloat16, float32=torch.float32)[a.dtype if dev == "cuda" else "float32"]
    tok = AutoTokenizer.from_pretrained(a.model, revision=a.revision, use_fast=True)
    kw = dict(revision=a.revision, torch_dtype=dt)
    if a.load_in_4bit:
        from transformers import BitsAndBytesConfig
        kw["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=dt)
        kw["device_map"] = "auto"
    model = AutoModel.from_pretrained(a.model, **kw)
    if not a.load_in_4bit:
        model = model.to(dev)
    model.eval()

    cache = {}

    @torch.no_grad()
    def vec(template, term):
        text, s, e = build_text(template, term)
        enc = tok(text, return_offsets_mapping=True, return_tensors="pt")
        off = enc.pop("offset_mapping")[0].tolist()
        idx = span_token_idx(off, s, e)
        out = model(**{k: v.to(model.device) for k, v in enc.items()}, output_hidden_states=True)
        H = torch.stack(out.hidden_states, 0)[:, 0]          # [L+1, T, d]
        return H[:, idx].float().mean(1).cpu().numpy(), len(idx)

    def emb(term, lang):
        key = (term, lang)
        if key not in cache:
            vs = [vec(t, term) for t in TEMPLATES[lang]]
            A = np.mean([v[0] for v in vs[0::2]], 0)
            B = np.mean([v[0] for v in vs[1::2]], 0)
            cache[key] = (A, B, float(np.mean([v[1] for v in vs])))
        return cache[key]

    lex = pd.read_csv(a.lexicon)
    EA, EB, G, N, nt = [], [], [], [], []
    for r in lex.itertuples():
        A, B, n = emb(r.term, r.lang)
        ga, gb, _ = emb(r.anchor_gloss, "en")
        na, nb, _ = emb(r.anchor_analog, "en")
        EA.append(A); EB.append(B); nt.append(n)
        G.append((ga + gb) / 2); N.append((na + nb) / 2)
    sig = hashlib.md5(lex.to_csv(index=False).encode("utf-8")).hexdigest()
    np.savez_compressed(a.out, lex_sig=sig, ids=lex["id"].values, E_A=np.array(EA, np.float16), E_B=np.array(EB, np.float16),
                        G=np.array(G, np.float16), N=np.array(N, np.float16), ntok=np.array(nt, np.float32),
                        model=a.model)
    print("saved", a.out, np.array(EA).shape)


if __name__ == "__main__":
    main()
