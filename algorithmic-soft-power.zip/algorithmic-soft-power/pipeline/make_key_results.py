"""Rebuild the headline table from raw run outputs so the transcription in key_results.csv can be verified.
Usage (from the repo root, after copying raw files into results/raw/):  python pipeline/make_key_results.py"""
import pandas as pd
o=pd.read_csv("results/raw/olmo_v2_results.csv"); q=pd.read_csv("results/raw/qwen_results.csv")
keep=["contrast","metric","lang","adj_diff","ci_lo","ci_hi","p_holm","family"]
a=o[(o.contrast=="sft->instruct")&(o.family=="primary")][keep].assign(run="OLMo-2 1B")
b=q[q.family=="primary"][keep].assign(run="Qwen2.5 1.5B")
st=o[(o.metric.isin(["shift_analog","shift_gloss"]))&(o.lang=="ar")&(o.contrast.isin(["sft->dpo","dpo->instruct","sft->instruct"]))][keep].assign(run="OLMo-2 1B")
out=pd.concat([a,b,st]).round(4); out.to_csv("results/key_results_regenerated.csv",index=False); print(out.to_string(index=False))
