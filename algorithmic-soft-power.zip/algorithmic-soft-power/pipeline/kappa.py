"""Inter-annotator agreement for the anchor annotation (two human annotators).
Usage: python kappa.py annotator1.csv annotator2.csv   (both filled copies of annotation_template.csv)
Reports quadratic-weighted Cohen's kappa (1-3 ordinal scales) and raw agreement; yes/no column: unweighted kappa."""
import sys, numpy as np, pandas as pd
def wkappa(x, y, cats, weighted=True):
    k = len(cats); idx = {c: i for i, c in enumerate(cats)}
    O = np.zeros((k, k))
    for a, b in zip(x, y): O[idx[a], idx[b]] += 1
    O /= O.sum(); E = np.outer(O.sum(1), O.sum(0))
    W = np.array([[((i - j) / (k - 1)) ** 2 if weighted else float(i != j) for j in range(k)] for i in range(k)])
    return 1 - (W * O).sum() / (W * E).sum()
a, b = pd.read_csv(sys.argv[1]), pd.read_csv(sys.argv[2]); assert (a.id == b.id).all()
for c in ["gloss_accuracy_1to3", "analogue_strength_1to3", "term_is_culture_specific_1to3"]:
    x, y = a[c].astype(int), b[c].astype(int)
    print(f"{c}: weighted kappa = {wkappa(x, y, [1,2,3]):.3f} | exact agreement = {(x==y).mean():.2f}")
c = "polysemy_or_cognate_yes_no"; x, y = a[c].str.lower().str[0], b[c].str.lower().str[0]
print(f"{c}: kappa = {wkappa(x, y, ['y','n'], weighted=False):.3f} | exact agreement = {(x==y).mean():.2f}")
