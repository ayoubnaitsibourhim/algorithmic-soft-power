"""Single-annotator (AI-assisted) audit of the 80 culture-term anchor pairs.
gloss_quality  : A accurate | B approximate | C poor
analogue_strength: S strong (a documented/common dominant-culture reframing) | P plausible | W weak (near-synonym, generic or loose)
flags: POLY homograph/polysemy (unvocalised Arabic or other sense) | COG orthographic cognate with the English gloss |
       LOAN English loanword | DISC low discriminability (analogue ~ near-synonym/translation) | DUP analogue reused within language |
       REG region-specific usage | PN proper noun / given name
"""
import pandas as pd
AR = """A S -|A S -|A P LOAN|A S -|A S -|B P -|B P POLY,REG|A P -|B W POLY|A S -|B W DISC|A W DISC|A S -|A W DISC|A P LOAN|A P POLY|A S -|A W DISC|A P -|A S -|A P POLY|A W DISC,DUP|A P DUP|A S -|B P -|A P -|A S -|A W POLY,DISC|A W DISC|A S -|A P -|A P -|A W -|A S -|A P -|A W POLY,PN|A P -|B W POLY|A S POLY|A W DISC""".split("|")
FR = """B S -|A P DUP|A S -|A P COG|A S COG|A P COG|A P COG,DUP|B S COG|A P LOAN|A S -|A P -|A W -|A W COG,DISC|A W POLY|B P LOAN|A S -|A P COG|A W -|A P COG|A P COG|B S -|A S -|A P COG|A W DISC|A S COG|B W -|A P -|A P -|A W DISC|A P -|A S -|A S -|A P POLY|A P -|A P -|A S COG|A S PN|B P -|B P -|A W COG,DISC""".split("|")
NOTES = {"car06":"MSA 'warehouse'; intended sense is the Moroccan state apparatus","car08":"also 'defect/flaw'","car09":"honor-vs-dignity cultures literature",
 "car12":"documented media framing; sensitive item","car15":"also 'conscience / financial liability'","car20":"colloquial 'calculation'","car22":"analogue 'religion' reused (car21)",
 "car27":"also verb 'he knew'","car35":"common given name","car37":"also 'office/department'","car38":"unvocalised homograph 'pond'",
 "cfr00":"scholars distinguish laicite from secularism","cfr13":"analogue 'assets' is the other sense of the word","cfr09":"analogue 'soft power' coincides with the paper's framing (circularity risk)",
 "cfr20":"false friend: US 'social security' = pensions","cfr28":"analogue is the standard translation of 'jus soli'","cfr32":"also 'lights'","cfr07":"pejorative French sense differs from philosophical communitarianism"}
lex = pd.read_csv("lexicon.csv")
cul = lex[lex.group.isin(["culture_ar","culture_fr"])].reset_index(drop=True)
assert len(cul)==80 and len(AR)==40 and len(FR)==40
rows=[]
for i,r in cul.iterrows():
    g,a,f = (AR if r.lang=="ar" else FR)[int(r.id[3:])].split()
    rows.append(dict(id=r.id, lang=r.lang, term=r.term, anchor_gloss=r.anchor_gloss, anchor_analog=r.anchor_analog,
                     gloss_quality=g, analogue_strength=a, flags="" if f=="-" else f, note=NOTES.get(r.id,"")))
d=pd.DataFrame(rows)
# verify DUP flags programmatically
for lang,g in d.groupby("lang"):
    dup=g[g.duplicated("anchor_analog",keep=False)]
    flagged=g[g["flags"].str.contains("DUP")]
    print(lang,"duplicated analogues:",sorted(dup.anchor_analog.unique()),"| DUP-flagged ids match:",set(dup.id)==set(flagged.id))
d.to_csv("anchor_audit.csv",index=False)
print(d.groupby("lang").analogue_strength.value_counts().unstack(fill_value=0))
print(d.groupby("lang").gloss_quality.value_counts().unstack(fill_value=0))
fl=d["flags"].str.get_dummies(sep=",").drop(columns=[""],errors="ignore"); print(fl.groupby(d.lang).sum())
amb=d["flags"].str.contains("POLY|COG|LOAN|PN|REG")
weak=(d.analogue_strength=="W")|d["flags"].str.contains("DISC|DUP")
for name,m in [("exclude_ambiguous",amb),("exclude_weak",weak),("exclude_all_flagged",amb|weak)]:
    d[m][["id"]].to_csv(f"{name}.csv",index=False); print(name,"excludes",m.sum(),d[m].groupby("lang").size().to_dict(),"-> remaining",d[~m].groupby("lang").size().to_dict())
strong=d[d.analogue_strength=="S"]; print("strong-only:",strong.groupby("lang").size().to_dict())
strong[["id"]].to_csv("keep_strong_only.csv",index=False)
# annotation template for two independent human annotators (blank ratings)
t=d[["id","lang","term","anchor_gloss","anchor_analog"]].copy()
for c in ["gloss_accuracy_1to3","analogue_strength_1to3","term_is_culture_specific_1to3","polysemy_or_cognate_yes_no","comments"]: t[c]=""
t.to_csv("annotation_template.csv",index=False)
