"""Builds lexicon.csv for the semantic-contamination study.

Groups
  culture_ar : Arabic terms whose meaning is embedded in a local socio-political / religious / kinship context
  culture_fr : French terms tied to the French republican / institutional context
  dominant_en: English terms that carry dominant (Anglo-American liberal) cultural assumptions
  control_{ar,fr,en}: culturally neutral concrete/abstract terms (empirical null for generic fine-tuning drift)

Anchors (both in English, embedded in the SAME model as the target term)
  anchor_gloss : literal translation gloss
  anchor_analog: the dominant-culture analogue a model might collapse the concept toward.
                 This is a RESEARCHER-DEFINED, contestable choice -> must be validated by >=2 bilingual annotators
                 (see README, 'Validity checks'). For English dominant terms: analog == gloss == term. For controls: analogue = a related NON-translation word (RELATED).
"""
import csv

CULTURE_AR = [  # term, gloss, analog
    ("شورى", "consultation", "democracy"),
    ("أمة", "community of believers", "nation"),
    ("خلافة", "caliphate", "empire"),
    ("زكاة", "obligatory almsgiving", "charity"),
    ("وقف", "religious endowment", "charitable foundation"),
    ("بيعة", "pledge of allegiance", "election"),
    ("مخزن", "traditional state apparatus", "government"),
    ("إمارة المؤمنين", "commandership of the faithful", "monarchy"),
    ("عيب", "social shame", "morality"),
    ("شرف", "honor", "dignity"),
    ("كرم", "generous hospitality", "generosity"),
    ("صلة الرحم", "maintaining kinship ties", "family"),
    ("جهاد", "striving in the way of God", "terrorism"),
    ("فتوى", "religious legal opinion", "legal ruling"),
    ("حلال", "religiously permitted", "legal"),
    ("ذمة", "protected minority status", "tolerance"),
    ("عروبة", "Arab identity", "nationalism"),
    ("وطن", "homeland", "country"),
    ("قبيلة", "kinship tribe", "ethnic group"),
    ("عصبية", "group solidarity", "tribalism"),
    ("حسبة", "market and moral oversight", "regulation"),
    ("تقوى", "God-consciousness", "religion"),
    ("ملة", "religious community", "religion"),
    ("الأسرة الممتدة", "extended family", "nuclear family"),
    ("مروءة", "magnanimous virtue", "chivalry"),
    ("تكافل", "mutual social solidarity", "welfare"),
    ("ربا", "usury", "interest rate"),
    ("عرف", "customary norm", "tradition"),
    ("ثأر", "blood vendetta", "revenge"),
    ("حياء", "moral modesty", "shyness"),
    ("أهل الكتاب", "People of the Book", "religious minorities"),
    ("إجماع", "scholarly consensus", "majority vote"),
    ("اجتهاد", "independent legal reasoning", "innovation"),
    ("بدعة", "unsanctioned religious innovation", "heresy"),
    ("عفة", "chastity and propriety", "purity"),
    ("رحمة", "merciful compassion", "pity"),
    ("أمانة", "sacred trust", "honesty"),
    ("مصلحة", "public welfare principle", "self-interest"),
    ("بركة", "spiritual blessing", "luck"),
    ("دار الإسلام", "domain of Islam", "Muslim world"),
]

CULTURE_FR = [
    ("laïcité", "state secularism", "religious freedom"),
    ("vivre-ensemble", "living together", "multiculturalism"),
    ("banlieue", "suburbs", "ghetto"),
    ("République", "republic", "democracy"),
    ("exception culturelle", "cultural exception", "protectionism"),
    ("universalisme", "universalism", "globalization"),
    ("assimilation", "assimilation", "multiculturalism"),
    ("communautarisme", "communitarianism", "identity politics"),
    ("francophonie", "French-speaking world", "cultural imperialism"),
    ("rayonnement", "cultural influence", "soft power"),
    ("grandes écoles", "elite higher-education schools", "university"),
    ("service public", "public service", "welfare"),
    ("fraternité", "brotherhood", "community"),
    ("patrimoine", "cultural heritage", "assets"),
    ("terroir", "regional land identity", "agriculture"),
    ("laïque", "secular", "atheist"),
    ("citoyenneté", "citizenship", "nationality"),
    ("droit de grève", "right to strike", "labor law"),
    ("cohésion sociale", "social cohesion", "integration"),
    ("identité nationale", "national identity", "patriotism"),
    ("sécurité sociale", "social insurance system", "pension"),
    ("État-providence", "welfare state", "socialism"),
    ("intellectuel engagé", "engaged intellectual", "activist"),
    ("bien commun", "common good", "public interest"),
    ("égalité", "equality", "equal opportunity"),
    ("devoir de réserve", "civil servants' duty of discretion", "censorship"),
    ("exception française", "French exceptionalism", "nationalism"),
    ("mixité sociale", "social mixing", "diversity"),
    ("droit du sol", "soil-based citizenship", "birthright citizenship"),
    ("pacte républicain", "republican pact", "social contract"),
    ("ordre public", "public order", "law and order"),
    ("quartiers populaires", "working-class neighborhoods", "slums"),
    ("Lumières", "Enlightenment", "modernity"),
    ("retraite par répartition", "pay-as-you-go pensions", "social security"),
    ("union sacrée", "sacred union", "national unity"),
    ("mission civilisatrice", "civilizing mission", "colonialism"),
    ("Françafrique", "France-Africa network", "neocolonialism"),
    ("politique de la ville", "urban policy", "urban renewal"),
    ("esprit critique", "critical spirit", "skepticism"),
    ("gastronomie", "gastronomy", "cuisine"),
]

DOMINANT_EN = [
    "individualism", "meritocracy", "free market", "privacy", "freedom of speech",
    "self-reliance", "entrepreneurship", "democracy", "human rights", "rule of law",
    "innovation", "pluralism", "secularism", "civil society", "liberalism",
    "equal opportunity", "personal freedom", "tolerance", "globalization", "nuclear family",
]

CONTROLS = [  # en, fr, ar
    ("water", "eau", "ماء"), ("stone", "pierre", "حجر"), ("river", "rivière", "نهر"),
    ("tree", "arbre", "شجرة"), ("number", "nombre", "عدد"), ("triangle", "triangle", "مثلث"),
    ("table", "table", "طاولة"), ("window", "fenêtre", "نافذة"), ("rain", "pluie", "مطر"),
    ("minute", "minute", "دقيقة"), ("metal", "métal", "معدن"), ("cloud", "nuage", "سحابة"),
    ("seed", "graine", "بذرة"), ("bridge", "pont", "جسر"), ("road", "route", "طريق"),
    ("salt", "sel", "ملح"), ("iron", "fer", "حديد"), ("mountain", "montagne", "جبل"),
    ("sand", "sable", "رمل"), ("door", "porte", "باب"), ("glass", "verre", "زجاج"),
    ("wheel", "roue", "عجلة"), ("circle", "cercle", "دائرة"), ("ladder", "échelle", "سلم"),
    ("moon", "lune", "قمر"), ("fish", "poisson", "سمك"), ("bone", "os", "عظم"),
    ("wall", "mur", "جدار"),
    ("sun", "soleil", "شمس"), ("star", "étoile", "نجمة"), ("leaf", "feuille", "ورقة"),
    ("egg", "œuf", "بيضة"), ("cup", "tasse", "كوب"), ("knife", "couteau", "سكين"),
    ("shoe", "chaussure", "حذاء"), ("clock", "horloge", "ساعة"), ("line", "ligne", "خط"),
    ("corner", "coin", "زاوية"), ("box", "boîte", "صندوق"), ("bottle", "bouteille", "زجاجة"),
]
# Related, NON-translation English anchor for each control (the control analogue of 'dominant analogue').
# Without this, controls were anchored to their literal translation and culture terms to a non-literal analogue,
# which confounded the culture-vs-control contrast (translation pairs converge across languages after post-training).
RELATED = {
    "water": "rain", "stone": "sand", "river": "water", "tree": "wood", "number": "count", "triangle": "circle",
    "table": "chair", "window": "door", "rain": "cloud", "minute": "hour", "metal": "steel", "cloud": "sky",
    "seed": "plant", "bridge": "road", "road": "street", "salt": "sugar", "iron": "steel", "mountain": "hill",
    "sand": "beach", "door": "gate", "glass": "window", "wheel": "car", "circle": "round", "ladder": "stairs",
    "moon": "sun", "fish": "sea", "bone": "skeleton", "wall": "brick", "sun": "light", "star": "sky",
    "leaf": "tree", "egg": "chicken", "cup": "tea", "knife": "blade", "shoe": "foot", "clock": "time",
    "line": "point", "corner": "angle", "box": "container", "bottle": "liquid",
}

rows = []
for i, (t, g, a) in enumerate(CULTURE_AR):
    rows.append((f"car{i:02d}", "ar", "culture_ar", t, g, a))
for i, (t, g, a) in enumerate(CULTURE_FR):
    rows.append((f"cfr{i:02d}", "fr", "culture_fr", t, g, a))
for i, t in enumerate(DOMINANT_EN):
    rows.append((f"den{i:02d}", "en", "dominant_en", t, t, t))
for i, (en, fr, ar) in enumerate(CONTROLS):
    rel = RELATED[en]
    rows.append((f"kar{i:02d}", "ar", "control_ar", ar, en, rel))
    rows.append((f"kfr{i:02d}", "fr", "control_fr", fr, en, rel))
    rows.append((f"ken{i:02d}", "en", "control_en", en, en, rel))

with open("lexicon.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["id", "lang", "group", "term", "anchor_gloss", "anchor_analog"])
    w.writerows(rows)
print(len(rows), "rows written")
