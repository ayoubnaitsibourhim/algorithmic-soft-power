#!/usr/bin/env bash
# Re-run on a Colab/Kaggle T4 (~20-30 min). The lexicon CHANGED (220 items, new control anchors) -> all embeddings must be re-extracted.
set -e
pip install -q "transformers>=4.48" accelerate pandas numpy scipy matplotlib sentencepiece
python build_lexicon.py
rm -rf emb results_olmo results_olmo_std results_qwen; mkdir -p emb
python extract.py --model allenai/OLMo-2-0425-1B          --out emb/olmo_base.npz
python extract.py --model allenai/OLMo-2-0425-1B-SFT      --out emb/olmo_sft.npz
python extract.py --model allenai/OLMo-2-0425-1B-DPO      --out emb/olmo_dpo.npz
python extract.py --model allenai/OLMo-2-0425-1B-Instruct --out emb/olmo_instruct.npz
# diagnostics first: check basis continuity and that nothing is degenerate
python diagnose.py base=emb/olmo_base.npz sft=emb/olmo_sft.npz dpo=emb/olmo_dpo.npz instruct=emb/olmo_instruct.npz | tee diagnostics_olmo.txt
# primary analysis (Amendment 1): preference stage = SFT -> final, shared coordinate basis
python run_analysis.py --tag olmo --out results_olmo --primary_contrast "sft->instruct" \
   base=emb/olmo_base.npz sft=emb/olmo_sft.npz dpo=emb/olmo_dpo.npz instruct=emb/olmo_instruct.npz
# sensitivity: per-dimension standardization (damps massive-activation dimensions)
python run_analysis.py --tag olmo_std --out results_olmo_std --standardize --primary_contrast "sft->instruct" \
   base=emb/olmo_base.npz sft=emb/olmo_sft.npz dpo=emb/olmo_dpo.npz instruct=emb/olmo_instruct.npz
# multilingual pair (base vs aligned; cross-boundary -> only basis-free metrics are valid if basis check fails)
python extract.py --model Qwen/Qwen2.5-1.5B          --out emb/qwen_base.npz
python extract.py --model Qwen/Qwen2.5-1.5B-Instruct --out emb/qwen_instruct.npz
python diagnose.py base=emb/qwen_base.npz instruct=emb/qwen_instruct.npz | tee diagnostics_qwen.txt
python run_analysis.py --tag qwen --out results_qwen base=emb/qwen_base.npz instruct=emb/qwen_instruct.npz
echo "DONE. Send: results_olmo/summary.md results_olmo/paired.csv results_olmo/basis_continuity.csv results_olmo/results.csv results_olmo_std/summary.md results_qwen/summary.md diagnostics_*.txt"
