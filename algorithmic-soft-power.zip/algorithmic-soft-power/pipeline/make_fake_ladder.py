"""SYNTHETIC 4-stage ladder in the extract.py format, with a planted effect ONLY at the DPO stage, ONLY for culture_ar
and culture_fr.  Used as a positive control for run_analysis.py.  NOT empirical data."""
import numpy as np, pandas as pd, os
rng = np.random.default_rng(11)
lex = pd.read_csv("lexicon.csv"); n = len(lex); L1, D = 17, 96
import hashlib
SIG = hashlib.md5(lex.to_csv(index=False).encode("utf-8")).hexdigest()
os.makedirs("fake", exist_ok=True)
cult = lex.group.str.startswith("culture").to_numpy()
ntok = np.where(cult, rng.integers(2, 7, n), rng.integers(1, 4, n)).astype(np.float32)

lat = rng.normal(size=(n, 1, D)) * np.linspace(0.3, 1, L1)[None, :, None]
E = lat + 0.8 * rng.normal(size=(n, L1, D))
G = 0.6 * E + 0.8 * rng.normal(size=(n, L1, D))
N = G.copy()
N[cult] = 0.5 * G[cult] + 0.9 * rng.normal(size=(cult.sum(), L1, D))
layer_gain = np.clip(np.linspace(-0.5, 1.2, L1), 0, 1)[None, :, None]   # effect lives in upper layers

def stage(E, G, N, lam, s_gen=0.25):
    E2 = E + s_gen * rng.normal(size=E.shape)
    E2[cult] += lam * layer_gain * (N[cult] - E[cult])
    return E2, G + 0.05 * rng.normal(size=G.shape), N + 0.05 * rng.normal(size=N.shape)

def save(name, E, G, N, rot=None):
    if rot is not None:
        E, G, N = [np.einsum("nld,lde->nle", X, rot) for X in (E, G, N)]
    jit = lambda X: X + 0.15 * rng.normal(size=X.shape)       # template-half noise
    np.savez_compressed(f"fake/{name}.npz", ids=lex.id.values, E_A=jit(E).astype(np.float16), E_B=jit(E).astype(np.float16),
                        G=G.astype(np.float16), N=N.astype(np.float16), ntok=ntok, model=f"SYNTHETIC-{name}", lex_sig=SIG)
# random orthogonal rotation per layer for the BASE checkpoint only (mimics the observed basis discontinuity)
ROT = np.stack([np.linalg.qr(rng.normal(size=(D, D)))[0] for _ in range(L1)])
cur = (E, G, N); save("base", *cur, rot=ROT); save("base_unrot", *cur)
for name, lam in (("sft", 0.0), ("dpo", 0.10), ("instruct", 0.0)):
    cur = stage(*cur, lam); save(name, *cur)
print("fake ladder written")
