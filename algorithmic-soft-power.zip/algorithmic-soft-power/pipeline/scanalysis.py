"""Metrics and inference for semantic contamination.

Conventions
  Embedding arrays have shape [n_items, n_layers, d].
  All cosine computations are done AFTER per-model, per-layer mean-centering (removes anisotropy; see Ethayarajh 2019).
  The same centering vector is applied to targets and anchors of a given model.
"""
from __future__ import annotations
import numpy as np

EPS = 1e-12


# ----------------------------------------------------------------------------- geometry
def center(E, G, N):
    """Subtract the per-layer mean of (targets U gloss anchors U analog anchors) from all three."""
    mu = np.concatenate([E, G, N], axis=0).mean(axis=0, keepdims=True)  # [1, L, d]
    return E - mu, G - mu, N - mu


def cos_rows(A, B):
    """Row-wise cosine for [n, L, d] arrays -> [n, L]."""
    num = (A * B).sum(-1)
    den = np.linalg.norm(A, axis=-1) * np.linalg.norm(B, axis=-1) + EPS
    return num / den


def knn_sets(E_layer, k):
    """E_layer: [n, d]. Returns list of neighbour index sets (cosine, self excluded)."""
    X = E_layer / (np.linalg.norm(E_layer, axis=1, keepdims=True) + EPS)
    S = X @ X.T
    np.fill_diagonal(S, -np.inf)
    idx = np.argpartition(-S, kth=min(k, S.shape[0] - 2), axis=1)[:, :k]
    return [set(r.tolist()) for r in idx]


def knn_drift(E_pre, E_post, langs, k=5):
    """1 - Jaccard overlap of k-NN sets among same-language items, per item and layer -> [n, L]."""
    n, L, _ = E_pre.shape
    out = np.zeros((n, L))
    for lang in np.unique(langs):
        ix = np.where(langs == lang)[0]
        for l in range(L):
            a = knn_sets(E_pre[ix, l], k)
            b = knn_sets(E_post[ix, l], k)
            for j, (sa, sb) in enumerate(zip(a, b)):
                out[ix[j], l] = 1.0 - len(sa & sb) / max(1, len(sa | sb))
    return out


def profile_drift(Ep, Eq, langs):
    """BASIS-FREE per-item drift: 1 - Pearson correlation between an item's similarity profile (cosine to every other
    same-language item) before and after. Invariant to any rotation of either model's coordinate system, so it is valid
    even when two checkpoints do not share a basis (observed: OLMo-2 base vs SFT/Instruct, cos ~ 0 at layer 0)."""
    n, L, _ = Ep.shape
    out = np.zeros((n, L))
    for lang in np.unique(langs):
        ix = np.where(langs == lang)[0]
        m = len(ix)
        mask = ~np.eye(m, dtype=bool)
        for l in range(L):
            Xp = Ep[ix, l] / (np.linalg.norm(Ep[ix, l], axis=1, keepdims=True) + EPS)
            Xq = Eq[ix, l] / (np.linalg.norm(Eq[ix, l], axis=1, keepdims=True) + EPS)
            A = (Xp @ Xp.T)[mask].reshape(m, m - 1)
            B = (Xq @ Xq.T)[mask].reshape(m, m - 1)
            A = A - A.mean(1, keepdims=True)
            B = B - B.mean(1, keepdims=True)
            corr = (A * B).sum(1) / (np.linalg.norm(A, axis=1) * np.linalg.norm(B, axis=1) + EPS)
            out[ix, l] = 1.0 - corr
    return out


def basis_continuity(pre, post):
    """Mean centred cosine between the SAME item in two checkpoints, per layer -> [L].
    ~1 : shared coordinate basis (cosine drift is meaningful). ~0 : basis discontinuity (use basis-free metrics only)."""
    Ep, _, _ = center(pre["E"], pre["G"], pre["N"])
    Eq, _, _ = center(post["E"], post["G"], post["N"])
    return cos_rows(Ep, Eq).mean(0)


def standardize_dims(E, G, N):
    """Per-dimension z-scoring (std over target items) to damp 'massive activation' dimensions. Sensitivity analysis."""
    sd = E.std(axis=0, keepdims=True) + EPS
    return E / sd, G / sd, N / sd


# ----------------------------------------------------------------------------- item-level metrics
def item_metrics(pre, post, langs, k=5, standardize=False):
    """pre/post: dict with E, G, N ([n, L, d]); returns dict of [n, L] arrays.

    drift          : 1 - cos(E_pre, E_post)   (Delta(w); ONLY valid when checkpoints share a coordinate basis)
    profile_drift  : 1 - corr of similarity profiles pre vs post (basis-free replacement for Delta(w))
    shift_analog   : cos(E_post, N_post) - cos(E_pre, N_pre)        (convergence toward dominant analogue)
    shift_gloss    : cos(E_post, G_post) - cos(E_pre, G_pre)        (convergence toward literal translation)
    knn_drift      : 1 - Jaccard@k of same-language neighbourhoods  (basis-free robustness metric)
    """
    Ep, Gp, Np = center(pre["E"], pre["G"], pre["N"])
    Eq, Gq, Nq = center(post["E"], post["G"], post["N"])
    drift_raw = 1.0 - cos_rows(Ep, Eq)          # computed BEFORE any standardization; valid only if bases are continuous
    if standardize:
        Ep, Gp, Np = standardize_dims(Ep, Gp, Np)
        Eq, Gq, Nq = standardize_dims(Eq, Gq, Nq)
    return {
        "drift": drift_raw,
        "profile_drift": profile_drift(Ep, Eq, langs),
        "shift_analog": cos_rows(Eq, Nq) - cos_rows(Ep, Np),
        "shift_gloss": cos_rows(Eq, Gq) - cos_rows(Ep, Gp),
        "knn_drift": knn_drift(Ep, Eq, langs, k),
        # baseline (pre-alignment) similarity to each anchor: covariates for the adjusted tests
        "base_analog": cos_rows(Ep, Np),
        "base_gloss": cos_rows(Ep, Gp),
    }


def layer_band(L, frac=0.5):
    """Pre-registered primary layers: upper half of the network, incl. final layer."""
    return list(range(int(np.floor(L * frac)), L))


# ----------------------------------------------------------------------------- inference
def hedges_g(x, y):
    nx, ny = len(x), len(y)
    sp = np.sqrt(((nx - 1) * x.var(ddof=1) + (ny - 1) * y.var(ddof=1)) / (nx + ny - 2))
    d = (x.mean() - y.mean()) / (sp + EPS)
    return d * (1 - 3 / (4 * (nx + ny) - 9))


def did_test(x, y, covar=None, n_boot=5000, n_perm=5000, seed=0):
    """Culture-vs-control difference in a per-item metric.

    x: metric for culture items, y: metric for control items.
    Returns mean difference, bootstrap 95% CI, two-sided permutation p, Hedges g.
    If covar=(cx, cy) (e.g., token counts) is given, also returns the OLS group coefficient adjusted for it.
    """
    rng = np.random.default_rng(seed)
    x, y = np.asarray(x, float), np.asarray(y, float)
    diff = x.mean() - y.mean()
    bs = np.empty(n_boot)
    for b in range(n_boot):
        bs[b] = rng.choice(x, len(x)).mean() - rng.choice(y, len(y)).mean()
    ci = (np.percentile(bs, 2.5), np.percentile(bs, 97.5))
    pool = np.concatenate([x, y])
    nx = len(x)
    cnt = 0
    for _ in range(n_perm):
        rng.shuffle(pool)
        if abs(pool[:nx].mean() - pool[nx:].mean()) >= abs(diff) - 1e-15:
            cnt += 1
    p = (cnt + 1) / (n_perm + 1)
    out = dict(diff=float(diff), ci_lo=float(ci[0]), ci_hi=float(ci[1]), p=float(p),
               g=float(hedges_g(x, y)), n_x=len(x), n_y=len(y))
    if covar is not None:
        cx, cy = covar
        X = np.column_stack([np.ones(len(x) + len(y)),
                             np.r_[np.ones(len(x)), np.zeros(len(y))],
                             np.r_[cx, cy]])
        beta, *_ = np.linalg.lstsq(X, np.r_[x, y], rcond=None)
        out["adj_diff"] = float(beta[1])
    return out


def ancova_test(y, group, covars, n_boot=5000, n_perm=5000, seed=0):
    """Baseline-adjusted group effect: y ~ 1 + group + covars (group: 1 = culture, 0 = control).

    Needed because generic fine-tuning noise shrinks cosines multiplicatively, so a raw before/after change in
    similarity is mechanically confounded with the BASELINE similarity (found in simulation: naive DiD has inflated
    type-I error when groups differ at baseline). Inference: Freedman-Lane permutation test for the group
    coefficient + stratified case-resampling bootstrap CI.
    """
    rng = np.random.default_rng(seed)
    y = np.asarray(y, float)
    g = np.asarray(group, float)
    C = np.asarray(covars, float)
    if C.ndim == 1:
        C = C[:, None]
    C = (C - C.mean(0)) / (C.std(0) + EPS)
    Xf = np.column_stack([np.ones(len(y)), g, C])
    Xr = np.column_stack([np.ones(len(y)), C])
    bf, *_ = np.linalg.lstsq(Xf, y, rcond=None)
    est = bf[1]
    br, *_ = np.linalg.lstsq(Xr, y, rcond=None)
    fit_r = Xr @ br
    res = y - fit_r
    # permutation (Freedman-Lane)
    cnt = 0
    for _ in range(n_perm):
        ys = fit_r + rng.permutation(res)
        b, *_ = np.linalg.lstsq(Xf, ys, rcond=None)
        if abs(b[1]) >= abs(est) - 1e-15:
            cnt += 1
    p = (cnt + 1) / (n_perm + 1)
    # stratified bootstrap
    i1, i0 = np.where(g == 1)[0], np.where(g == 0)[0]
    bs = np.empty(n_boot)
    for k in range(n_boot):
        ix = np.r_[rng.choice(i1, len(i1)), rng.choice(i0, len(i0))]
        b, *_ = np.linalg.lstsq(Xf[ix], y[ix], rcond=None)
        bs[k] = b[1]
    return dict(adj_diff=float(est), ci_lo=float(np.percentile(bs, 2.5)), ci_hi=float(np.percentile(bs, 97.5)),
                p=float(p), n_x=int(len(i1)), n_y=int(len(i0)))


def holm(pvals):
    """Holm-Bonferroni adjusted p-values."""
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i])
        adj[i] = min(1.0, run)
    return adj.tolist()


def band_mean(M, layers):
    """Average an [n, L] metric over the chosen layers -> [n]."""
    return M[:, layers].mean(axis=1)
