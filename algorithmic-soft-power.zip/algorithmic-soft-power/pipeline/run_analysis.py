"""Run the full analysis on extracted embeddings.

Usage (ordered ladder, first = earliest checkpoint):
  python run_analysis.py --tag olmo --out results_olmo --primary_contrast sft->instruct \
      base=emb/olmo_base.npz sft=emb/olmo_sft.npz dpo=emb/olmo_dpo.npz instruct=emb/olmo_instruct.npz

PLAN (v2 = Amendment 1, made AFTER measurement diagnostics, BEFORE re-running with the revised lexicon; disclose in the paper)
  v1 (original): primary contrast base->final, metrics {drift, shift_analog}, layers = upper half incl. final layer.
  Diagnostics on the first real run showed (i) a coordinate-basis discontinuity between the OLMo base and every
  post-trained checkpoint (centred cosine ~0 at layer 0, RSA ~0.93) -> cosine `drift` across that boundary is invalid;
  (ii) the final layer is dominated by one dimension (top-1 variance 0.45) -> excluded; (iii) controls were anchored to
  their literal translation while culture terms were anchored to a non-literal analogue -> culture-vs-control contrast
  confounded by anchor type -> controls now use a related non-translation anchor.
  v2: primary contrast = --primary_contrast (default: first->last); primary metrics {profile_drift, shift_analog};
  layers = upper half excluding the last layer; `drift` reported only where basis continuity holds.
  Primary family = {profile_drift, shift_analog} x {ar, fr} on the primary contrast (Holm). All else exploratory.
  The v1 results must still be reported in the paper as the originally planned analysis.
"""
import argparse, json, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import scanalysis as sa

COMPARISONS = [("culture_ar", "control_ar", "ar"), ("culture_fr", "control_fr", "fr"), ("dominant_en", "control_en", "en")]
METRICS = ["profile_drift", "drift", "shift_analog", "shift_gloss", "knn_drift", "paired_C"]
PRIMARY = {("profile_drift", "ar"), ("profile_drift", "fr"), ("shift_analog", "ar"), ("shift_analog", "fr")}


def load(path):
    z = np.load(path, allow_pickle=True)
    return dict(E=(z["E_A"].astype(np.float32) + z["E_B"].astype(np.float32)) / 2, G=z["G"].astype(np.float32),
                N=z["N"].astype(np.float32), EA=z["E_A"].astype(np.float32), EB=z["E_B"].astype(np.float32),
                ntok=z["ntok"].astype(float), ids=z["ids"], model=str(z["model"]),
                sig=str(z["lex_sig"]) if "lex_sig" in z.files else None)


def boot_ci(x, n=10000, seed=0):
    rng = np.random.default_rng(seed)
    return np.percentile([rng.choice(x, len(x)).mean() for _ in range(n)], [2.5, 97.5])


def signflip_p(x, n=10000, seed=0):
    rng = np.random.default_rng(seed)
    obs = abs(x.mean())
    c = sum(abs((x * rng.choice([-1, 1], len(x))).mean()) >= obs - 1e-15 for _ in range(n))
    return (c + 1) / (n + 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="run")
    ap.add_argument("--out", default="results")
    ap.add_argument("--lexicon", default="lexicon.csv")
    ap.add_argument("--n_boot", type=int, default=5000)
    ap.add_argument("--n_perm", type=int, default=10000)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--primary_contrast", default=None, help="e.g. sft->instruct (default: first->last)")
    ap.add_argument("--include_last_layer", action="store_true")
    ap.add_argument("--standardize", action="store_true", help="per-dimension z-scoring sensitivity analysis")
    ap.add_argument("--exclude_file", default=None, help="CSV with column id: items dropped from group comparisons (anchor-quality sensitivity)")
    ap.add_argument("--keep_file", default=None, help="CSV with column id: restrict CULTURE items to this set (controls untouched)")
    ap.add_argument("--allow_stale", action="store_true", help="skip lexicon-signature check (NOT recommended)")
    ap.add_argument("stages", nargs="+", help="name=path.npz in training order")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    lex = pd.read_csv(a.lexicon)
    import hashlib
    sig = hashlib.md5(lex.to_csv(index=False).encode("utf-8")).hexdigest()
    names = [s.split("=")[0] for s in a.stages]
    data = {s.split("=")[0]: load(s.split("=")[1]) for s in a.stages}
    for n in names:
        assert (data[n]["ids"] == lex["id"].values).all(), f"{n}: item order differs from lexicon"
        if not a.allow_stale:
            assert data[n]["sig"] == sig, (f"{n}: embeddings were extracted with a DIFFERENT lexicon "
                                           f"(anchors/terms changed). Re-run extract.py.")
    langs = lex["lang"].to_numpy(dtype=object)
    groups = lex["group"].to_numpy(dtype=object)
    keep = np.ones(len(lex), dtype=bool)
    if a.exclude_file:
        keep &= ~lex["id"].isin(set(pd.read_csv(a.exclude_file)["id"])).to_numpy()
    if a.keep_file:
        kept = set(pd.read_csv(a.keep_file)["id"])
        is_cult = lex["group"].str.startswith("culture").to_numpy()
        keep &= ~(is_cult & ~lex["id"].isin(kept).to_numpy())
    L = data[names[0]]["E"].shape[1]
    layers = sa.layer_band(L)
    if not a.include_last_layer:
        layers = layers[:-1]

    contrasts = [(names[i], names[j]) for i in range(len(names)) for j in range(i + 1, len(names))]
    if a.primary_contrast:
        p_, q_ = a.primary_contrast.split("->")
        assert (p_, q_) in contrasts, f"{a.primary_contrast} not in {contrasts}"
        final_contrast = (p_, q_)
    else:
        final_contrast = (names[0], names[-1])

    # ---- noise floor
    nf = []
    for n in names:
        d = data[n]
        Ec, _, _ = sa.center(d["EA"], d["G"], d["N"])
        Ec2, _, _ = sa.center(d["EB"], d["G"], d["N"])
        nz = sa.band_mean(1 - sa.cos_rows(Ec, Ec2), layers)
        for g in np.unique(groups):
            nf.append(dict(model=n, group=g, split_half_noise=float(nz[groups == g].mean())))
    pd.DataFrame(nf).to_csv(f"{a.out}/noise_floor.csv", index=False)

    rows, item_rows, paired_rows, curves, bc_rows = [], [], [], {}, []
    for (p, q) in contrasts:
        bc = sa.basis_continuity(data[p], data[q])
        bc_band = float(np.median(bc[layers]))
        valid_cos = bc_band > 0.5
        bc_rows.append(dict(contrast=f"{p}->{q}", median_centered_cos_band=bc_band, cosine_drift_valid=valid_cos,
                            layer0_cos=float(bc[0])))
        if not valid_cos:
            print(f"WARNING {p}->{q}: no shared coordinate basis (median centred cos {bc_band:.3f}); "
                  f"cosine `drift` flagged INVALID, use profile_drift / knn_drift / shift_* (basis-free).")
        M = sa.item_metrics(data[p], data[q], langs, k=a.k, standardize=a.standardize)
        M["paired_C"] = M["shift_analog"] - M["shift_gloss"]   # C(w): analogue-ward minus gloss-ward shift (exploratory formal culture-vs-control test)
        ntok = (data[p]["ntok"] + data[q]["ntok"]) / 2
        for m in METRICS:
            band = sa.band_mean(M[m], layers)
            for i in range(len(lex)):
                item_rows.append(dict(contrast=f"{p}->{q}", metric=m, id=lex.id[i], term=lex.term[i],
                                      group=groups[i], value=float(band[i])))
            for cg, kg, lg in COMPARISONS:
                ix = np.where(((groups == cg) | (groups == kg)) & keep)[0]
                y = band[ix]
                grp = (groups[ix] == cg).astype(float)
                base = sa.band_mean(M["base_analog" if m == "shift_analog" else "base_gloss"], layers)[ix]
                cov = np.column_stack([base, ntok[ix]])
                r = sa.ancova_test(y, grp, cov, n_boot=a.n_boot, n_perm=a.n_perm, seed=1)
                raw = sa.did_test(y[grp == 1], y[grp == 0], n_boot=1000, n_perm=1000, seed=1)
                valid = not (m == "drift" and not valid_cos)
                r.update(contrast=f"{p}->{q}", metric=m, lang=lg, raw_diff=raw["diff"], hedges_g=raw["g"],
                         mean_culture=float(y[grp == 1].mean()), mean_control=float(y[grp == 0].mean()),
                         valid=valid, primary=bool(valid and (p, q) == final_contrast and (m, lg) in PRIMARY))
                rows.append(r)
            if (p, q) == final_contrast:
                curves[m] = {g: M[m][groups == g].mean(0) for g in np.unique(groups)}
        # paired within-term test: shift toward analogue minus shift toward literal gloss
        d_all = sa.band_mean(M["shift_analog"] - M["shift_gloss"], layers)
        for g in ("culture_ar", "culture_fr", "control_ar", "control_fr", "dominant_en"):
            d = d_all[(groups == g) & keep]
            lo, hi = boot_ci(d)
            paired_rows.append(dict(contrast=f"{p}->{q}", group=g, mean_analog_minus_gloss=float(d.mean()),
                                    ci_lo=float(lo), ci_hi=float(hi), p=signflip_p(d), n=len(d)))

    res = pd.DataFrame(rows)
    res["p_holm"] = np.nan
    fam = np.where(~res["valid"], "invalid_basis", np.where(res["primary"], "primary", "exploratory"))
    res["family"] = fam
    for f in ("primary", "exploratory"):
        msk = res["family"] == f
        res.loc[msk, "p_holm"] = sa.holm(res.loc[msk, "p"].values)
    res.to_csv(f"{a.out}/results.csv", index=False)
    pd.DataFrame(item_rows).to_csv(f"{a.out}/item_level.csv", index=False)
    pd.DataFrame(bc_rows).to_csv(f"{a.out}/basis_continuity.csv", index=False)
    pr = pd.DataFrame(paired_rows)
    pr["p_holm"] = sa.holm(pr["p"].values)
    pr.to_csv(f"{a.out}/paired.csv", index=False)

    # ---------------- figures
    fig, axs = plt.subplots(2, 3, figsize=(12, 6), sharex=True)
    for r_, m in enumerate(["profile_drift", "shift_analog"]):
        for c_, (cg, kg, lg) in enumerate(COMPARISONS):
            ax = axs[r_, c_]
            ax.plot(curves[m][cg], label=cg, color="C3", marker="o", ms=3)
            ax.plot(curves[m][kg], label=kg, color="C0", marker="o", ms=3)
            ax.axvspan(layers[0], layers[-1], color="grey", alpha=0.08)
            ax.set_title(f"{m} ({lg})", fontsize=9)
            if r_ == 1: ax.set_xlabel("layer (shaded = analysed band)")
            ax.legend(frameon=False, fontsize=7)
    fig.suptitle(f"{a.tag}: layer-wise effect, {final_contrast[0]} -> {final_contrast[1]}", fontsize=10)
    fig.tight_layout(); fig.savefig(f"{a.out}/fig_layers.png", dpi=200); plt.close(fig)

    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    for ax, m in zip(axs, ["profile_drift", "shift_analog"]):
        sub = res[(res.metric == m) & (res.lang != "en")]
        cons = list(dict.fromkeys(sub.contrast))
        for j, lg in enumerate(["ar", "fr"]):
            s2 = sub[sub.lang == lg].set_index("contrast").loc[cons]
            x = np.arange(len(cons)) + (j - 0.5) * 0.3
            ax.errorbar(x, s2.adj_diff, yerr=[s2.adj_diff - s2.ci_lo, s2.ci_hi - s2.adj_diff], fmt="o", capsize=3,
                        label=lg, color=f"C{j+1}")
        ax.axhline(0, color="grey", lw=1)
        ax.set_xticks(range(len(cons))); ax.set_xticklabels(cons, rotation=20, fontsize=8)
        ax.set_title(f"Adjusted culture - control effect: {m}", fontsize=9)
        ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(f"{a.out}/fig_stages.png", dpi=200); plt.close(fig)

    # ---------------- summary
    fc = f"{final_contrast[0]}->{final_contrast[1]}"
    out = [f"# Summary ({a.tag}) | primary contrast {fc} | analysed layers {layers[0]}-{layers[-1]} of {L-1}"
           f"{' | per-dim standardized' if a.standardize else ''}"
           f"{' | items kept: ' + str(int(keep.sum())) + '/' + str(len(lex)) if not keep.all() else ''}\n", "## Basis continuity (cosine drift valid only if > 0.5)"]
    for r in bc_rows:
        out.append(f"- {r['contrast']}: median centred cos = {r['median_centered_cos_band']:.3f} "
                   f"(layer 0: {r['layer0_cos']:.3f}) -> cosine drift {'valid' if r['cosine_drift_valid'] else 'INVALID'}")
    out.append("\n## Primary family (Holm)")
    for r in res[res.primary].itertuples():
        out.append(f"- {r.metric} [{r.lang}]: adj. culture-control diff = {r.adj_diff:+.4f} (95% CI {r.ci_lo:+.4f}, {r.ci_hi:+.4f}); "
                   f"p = {r.p:.4f}, Holm p = {r.p_holm:.4f}; raw means {r.mean_culture:.4f} vs {r.mean_control:.4f}, g = {r.hedges_g:.2f}")
    out.append("\n## Paired within-term test: shift toward analogue minus shift toward literal gloss (>0 = contamination direction)")
    for r in pr[pr.contrast == fc].itertuples():
        out.append(f"- {r.group}: {r.mean_analog_minus_gloss:+.4f} (95% CI {r.ci_lo:+.4f}, {r.ci_hi:+.4f}), Holm p = {r.p_holm:.4f}, n = {r.n}")
    out.append("\n## Exploratory results with Holm p < .05")
    for r in res[(res.family == "exploratory") & (res.p_holm < 0.05)].itertuples():
        out.append(f"- {r.contrast} {r.metric} [{r.lang}]: adj diff {r.adj_diff:+.4f} CI ({r.ci_lo:+.4f}, {r.ci_hi:+.4f}), Holm p = {r.p_holm:.4f}")
    open(f"{a.out}/summary.md", "w").write("\n".join(out))
    print("\n".join(out))


if __name__ == "__main__":
    main()
