"""Validation of the inference pipeline on SYNTHETIC embeddings (these are NOT empirical results).

Generative model (per layer):
  pre-alignment:  target vectors e_i, gloss anchors g_i = rho*e_i + noise, analog anchors a_i (culture) or g_i (control)
  post-alignment: every item receives generic fine-tuning drift ~ N(0, s_generic);
                  culture items additionally get a pull toward their analogue: e_i += lam * (a_i - e_i)
Questions answered:
  1. Is the false-positive rate ~ alpha when lam = 0 (no culture-specific effect)?
  2. What power do we have for a given lam and lexicon size per group?
"""
import numpy as np, pandas as pd, time, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import scanalysis as sa

D, L = 64, 4
RHO = 0.6
S_GENERIC = 0.35


def make_pair(n_c, n_k, lam, rng):
    n = n_c + n_k
    E = rng.normal(size=(n, L, D))
    G = RHO * E + np.sqrt(1 - RHO ** 2) * rng.normal(size=(n, L, D))
    Nn = G.copy()
    A = 0.5 * G[:n_c] + np.sqrt(0.75) * rng.normal(size=(n_c, L, D))  # analogue differs from literal gloss
    Nn[:n_c] = A
    pre = dict(E=E, G=G, N=Nn)

    drift_e = S_GENERIC * rng.normal(size=E.shape)
    E2 = E + drift_e
    E2[:n_c] += lam * (Nn[:n_c] - E[:n_c])
    G2 = G + 0.1 * rng.normal(size=G.shape)
    N2 = Nn.copy()
    N2[n_c:] = G2[n_c:]
    N2[:n_c] = Nn[:n_c] + 0.1 * rng.normal(size=(n_c, L, D))
    post = dict(E=E2, G=G2, N=N2)
    return pre, post


def one_rep(n_c, n_k, lam, rng, nb, npm):
    pre, post = make_pair(n_c, n_k, lam, rng)
    Ep, Gp, Np = sa.center(pre["E"], pre["G"], pre["N"])
    Eq, Gq, Nq = sa.center(post["E"], post["G"], post["N"])
    shift = sa.cos_rows(Eq, Nq) - sa.cos_rows(Ep, Np)
    layers = sa.layer_band(L)
    m = sa.band_mean(shift, layers)
    base = sa.band_mean(sa.cos_rows(Ep, Np), layers)          # baseline similarity to the anchor
    seed = int(rng.integers(1e9))
    naive = sa.did_test(m[:n_c], m[n_c:], n_boot=nb, n_perm=npm, seed=seed)
    grp = np.r_[np.ones(n_c), np.zeros(n_k)]
    adj = sa.ancova_test(m, grp, base, n_boot=nb, n_perm=npm, seed=seed)
    return naive["p"], adj["p"], adj["adj_diff"]


def main(reps=200, nb=400, npm=400):
    rng = np.random.default_rng(7)
    rows = []
    t0 = time.time()
    for n_per in (10, 20, 25, 40):
        for lam in (0.0, 0.01, 0.02, 0.05):
            pn, pa, ds = [], [], []
            for _ in range(reps):
                a, b, d = one_rep(n_per, n_per, lam, rng, nb, npm)
                pn.append(a); pa.append(b); ds.append(d)
            pn, pa = np.array(pn), np.array(pa)
            rows.append(dict(n_per_group=n_per, lam=lam, reject_naive=float((pn < 0.05).mean()),
                             reject_adjusted=float((pa < 0.05).mean()),
                             mean_adj_effect=float(np.mean(ds)), reps=reps))
            print(rows[-1], f"{time.time()-t0:.0f}s", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv("simulation_power.csv", index=False)

    fig, axs = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    for ax, col, ttl in zip(axs, ("reject_naive", "reject_adjusted"),
                            ("Naive culture-vs-control test", "Baseline-adjusted (ANCOVA, Freedman-Lane)")):
        for n_per, g in df.groupby("n_per_group"):
            ax.plot(g["lam"], g[col], marker="o", label=f"n = {n_per} / group")
        ax.axhline(0.05, color="grey", ls=":", lw=1)
        ax.axhline(0.80, color="grey", ls="--", lw=1)
        ax.set_xlabel("true pull toward dominant analogue (lambda)")
        ax.set_title(ttl, fontsize=10)
    axs[0].set_ylabel("rejection rate (alpha = .05)")
    axs[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Synthetic validation: type-I error at lambda = 0 and power (synthetic data, not empirical results)", fontsize=10)
    fig.tight_layout()
    fig.savefig("simulation_power.png", dpi=200)
    return df


if __name__ == "__main__":
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    main(reps=reps)
