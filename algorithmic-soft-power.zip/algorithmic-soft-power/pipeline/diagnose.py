"""Diagnostics for the suspicious `drift ~ 1.0` result.  Run where your emb/*.npz files are (Colab).

  python diagnose.py base=emb/olmo_base.npz instruct=emb/olmo_instruct.npz [sft=... dpo=...]

Prints, per layer, for the FIRST vs LAST stage (and consecutive stages):
  cos_raw      mean cosine pre vs post WITHOUT centering
  cos_centered mean cosine pre vs post after the per-model mean-centering used in run_analysis.py (= 1 - drift)
  rsa          Spearman correlation of the item-by-item similarity structure pre vs post (rotation/basis-free)
  cka          linear CKA between pre and post item matrices (rotation-invariant)
  split_half   centered cosine between template halves A and B inside ONE model (measurement reliability ceiling)
  top1_var     share of centered variance on the single largest dimension (massive-activation check)
Interpretation:
  rsa/cka high but cos_centered ~ 0  -> structure preserved; per-dimension drift metric is dominated by a few
                                        high-variance dims or small-sample centering -> use RSA/CKA/kNN, not cosine.
  split_half low                     -> terms are not embedded reliably (templates/tokenisation) -> fix extraction.
  rsa also ~ 0                       -> pre/post are genuinely unrelated OR items are misaligned/corrupted.
Then prints the PAIRED test that avoids the control-anchor asymmetry (see README note):
  for culture items, shift toward analogue minus shift toward literal gloss, per language.
"""
import sys, numpy as np, pandas as pd
from scipy.stats import spearmanr
import scanalysis as sa

def load(p):
    z = np.load(p, allow_pickle=True)
    E = (z["E_A"].astype(np.float32) + z["E_B"].astype(np.float32)) / 2
    return dict(E=E, EA=z["E_A"].astype(np.float32), EB=z["E_B"].astype(np.float32),
                G=z["G"].astype(np.float32), N=z["N"].astype(np.float32))

def cka(X, Y):
    X = X - X.mean(0); Y = Y - Y.mean(0)
    hsic = np.linalg.norm(X.T @ Y) ** 2
    return hsic / (np.linalg.norm(X.T @ X) * np.linalg.norm(Y.T @ Y) + 1e-12)

def rsa(X, Y):
    def sim(A):
        A = A - A.mean(0); A = A / (np.linalg.norm(A, axis=1, keepdims=True) + 1e-12); S = A @ A.T
        return S[np.triu_indices(len(A), 1)]
    return spearmanr(sim(X), sim(Y))[0]

def main(args):
    lex = pd.read_csv("lexicon.csv")
    names = [a.split("=")[0] for a in args]; D = {a.split("=")[0]: load(a.split("=")[1]) for a in args}
    langs = lex.lang.to_numpy(dtype=object); groups = lex.group.to_numpy(dtype=object)
    pairs = [(names[0], names[-1])] + [(names[i], names[i + 1]) for i in range(len(names) - 1) if len(names) > 2]
    for p, q in pairs:
        print(f"\n=== {p} -> {q}")
        for nm in (p, q):
            bad = ~np.isfinite(D[nm]["E"]).all(); print(f"  {nm}: non-finite values present: {bool(bad)}")
        L = D[p]["E"].shape[1]; rows = []
        Ep, Gp, Np = sa.center(D[p]["E"], D[p]["G"], D[p]["N"]); Eq, Gq, Nq = sa.center(D[q]["E"], D[q]["G"], D[q]["N"])
        for l in range(L):
            raw = sa.cos_rows(D[p]["E"][:, l:l+1], D[q]["E"][:, l:l+1]).mean()
            cen = sa.cos_rows(Ep[:, l:l+1], Eq[:, l:l+1]).mean()
            sh = []
            for nm in (p, q):
                A, B, _ = sa.center(D[nm]["EA"], D[nm]["G"], D[nm]["N"]); B2, _, _ = sa.center(D[nm]["EB"], D[nm]["G"], D[nm]["N"])
                sh.append(sa.cos_rows(A[:, l:l+1], B2[:, l:l+1]).mean())
            sv = np.linalg.svd(Ep[:, l] - Ep[:, l].mean(0), compute_uv=False) ** 2
            rows.append(dict(layer=l, cos_raw=raw, cos_centered=cen, rsa=rsa(D[p]["E"][:, l], D[q]["E"][:, l]),
                             cka=cka(D[p]["E"][:, l], D[q]["E"][:, l]), split_half_pre=sh[0], split_half_post=sh[1],
                             top1_var=float(sv[0] / sv.sum())))
        print(pd.DataFrame(rows).round(3).to_string(index=False))

    p, q = names[0], names[-1]
    Ep, Gp, Np = sa.center(D[p]["E"], D[p]["G"], D[p]["N"]); Eq, Gq, Nq = sa.center(D[q]["E"], D[q]["G"], D[q]["N"])
    layers = sa.layer_band(Ep.shape[1])
    s_an = sa.band_mean(sa.cos_rows(Eq, Nq) - sa.cos_rows(Ep, Np), layers)
    s_gl = sa.band_mean(sa.cos_rows(Eq, Gq) - sa.cos_rows(Ep, Gp), layers)
    print(f"\n=== PAIRED within-term test ({p}->{q}): shift_analog - shift_gloss (positive = pulled toward the dominant analogue MORE than toward its translation)")
    rng = np.random.default_rng(0)
    for g in ("culture_ar", "culture_fr"):
        d = (s_an - s_gl)[groups == g]
        bs = [rng.choice(d, len(d)).mean() for _ in range(10000)]
        print(f"  {g}: mean = {d.mean():+.4f}  95% CI ({np.percentile(bs,2.5):+.4f}, {np.percentile(bs,97.5):+.4f})  n = {len(d)}")
    print("\nPer-item (largest analogue-minus-gloss shifts):")
    t = pd.DataFrame(dict(term=lex.term, group=groups, d=s_an - s_gl, analog=lex.anchor_analog))
    print(t[t.group.str.startswith("culture")].sort_values("d", ascending=False).head(10).round(4).to_string(index=False))

if __name__ == "__main__":
    main(sys.argv[1:])
